---
title: "Welcome to Sciency!"
date: 2025-07-24
---

This is your first blog post! You can write new articles every week using the admin panel.
